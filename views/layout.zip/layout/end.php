    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= APP_URL . 'assets/js/app.js' ?>"></script>
  </body>
</html>
